import json
import statistics
import logging
from sagemaker.model import Model


logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info("test")
    predictor = loadModel()
    testTweets = ["I am so happy!", "I hate life"]
    result = predict(testTweets,predictor)
    response = {'result': result}
    return response

def loadModel():
    pred_model = Model(model_data="s3://tweetheettrainingdata/TweetHeet-clone/Model/TweetHeet-1/data-processor-models/TweetHeet--dpp9-1-30dfc09773614188865f2bd6dd5bb64c4bdd92ff23f04/output/model.tar.gz")
    predictor = pred_model.deploy(initial_instance_count=1, instance_type='local_cpu')
    return predictor
    
def predict(tweets,predictor):
    results = []
    for i in tweets:
        results.append(predictor.predict(i))
    return statistics.mean(results)
        
 